// next.config.js
module.exports = {
    images: {
      domains: ['res.cloudinary.com'], // Add your trusted domains here
    },
  };
  